#ifndef _PALINDROME_CHECKER_H_
#define _PALINDROME_CHECKER_H_

int is_palindrome(char *str);

#endif