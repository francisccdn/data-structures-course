#ifndef _EXPR_CHECK_H_
#define _EXPR_CHECK_H_

int valid_expr(char* expr);

#endif